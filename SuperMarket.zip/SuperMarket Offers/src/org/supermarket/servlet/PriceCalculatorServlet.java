package org.supermarket.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.supermarket.POJO.Items;
import org.supermarket.POJO.Quantity;
import org.supermarket.service.CalculateSP;

/**
 * Servlet implementation class priceCalculatorServlet
 */
@WebServlet("/priceCalculatorServlet")
public class PriceCalculatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PriceCalculatorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<Quantity> quantityList = null;
		List<Items> itemsList = null;
		Quantity quantity = null;
		String[] array={"A","B","C","D","E"};  
		int[] qArray = null;
		
		try {
			qArray = new int[5];
			
			qArray[0]  = Integer.parseInt(request.getParameter("aCount"));
			qArray[1]  = Integer.parseInt(request.getParameter("bCount"));
			qArray[2]  = Integer.parseInt(request.getParameter("cCount"));
			qArray[3]  = Integer.parseInt(request.getParameter("dCount"));
			qArray[4]  = Integer.parseInt(request.getParameter("eCount"));
			
			quantityList = new ArrayList<Quantity>();
			for(int i= 0; i< 5; i++){
				quantity = new Quantity();
				quantity.setItem(array[i]);
				quantity.setQuantity(qArray[i]);
				quantityList.add(quantity);
			}
			
			CalculateSP cal = new CalculateSP();
			itemsList = cal.calculate(quantityList);
			for(int i= 0; i< 5; i++){
				System.out.println("itemsList :"+itemsList.get(i).getItem());
				System.out.println("itemsListPrice :"+itemsList.get(i).getPrice());
			}
			
			//request.setAttribute("variable", itemsList.toArray(new Items[itemsList.size()]));
			request.setAttribute("cartItems", itemsList);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/CheckOut.jsp");
			dispatcher.forward(request, response);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
