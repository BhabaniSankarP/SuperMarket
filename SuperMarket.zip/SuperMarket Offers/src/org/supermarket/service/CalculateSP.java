package org.supermarket.service;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.supermarket.POJO.Items;
import org.supermarket.POJO.Quantity;

public class CalculateSP {


	public List<Items> calculate(List<Quantity> quantityList){

		Items items = null;
		List<Items> itemsList = null;

		double itemPrice = 0;

		try {
			JSONParser jsonParser = new JSONParser();
			FileReader fileReader = new FileReader("F:\\file.json");
			Object obj = jsonParser.parse(fileReader);
			JSONObject jsonObj = (JSONObject)obj;

			String itemAPrice = (String) jsonObj.get("A");
			String itemBPrice = (String)jsonObj.get("B");
			String itemCPrice = (String)jsonObj.get("C");
			String itemDPrice = (String)jsonObj.get("D");
			String itemEPrice = (String)jsonObj.get("E");

			/*JSONArray jsonArray = (JSONArray)jsonObj.get("A");

			for(int i = 0;i < jsonArray.size();i++){
				String unitPrice = (String) jsonObj.get("1");
				String specialPrice = (String) jsonObj.get("3");
			}*/



			itemsList = new ArrayList<Items>();
			
			for(int i= 0;i<=quantityList.size();i++){
				items = new Items();
				if(quantityList != null){
					if(quantityList.get(i).getItem().equalsIgnoreCase("A") && quantityList.get(i).getQuantity()>0){
						itemPrice = 0;
						if(quantityList.get(i).getQuantity()>= 3){
							if(quantityList.get(i).getQuantity()%3 == 0){
								itemPrice = (quantityList.get(i).getQuantity()/3)* 130;
								System.out.println("item if:" +quantityList.get(i).getItem()+" : "+ itemPrice);
							}else{
								int quotient = quantityList.get(i).getQuantity()/3;
								int remainder = quantityList.get(i).getQuantity()%3;
								itemPrice = remainder * Double.parseDouble(itemAPrice);
								itemPrice += quotient * 130;
								System.out.println("item else if:" +quantityList.get(i).getItem()+" : "+ itemPrice);
							}
						}else{
							itemPrice = quantityList.get(i).getQuantity() * Double.parseDouble(itemAPrice);
							System.out.println("item else:" +quantityList.get(i).getItem()+" : "+ itemPrice);
						}
						items.setItem(quantityList.get(i).getItem());
						items.setPrice(itemPrice);
						itemsList.add(items);
						System.out.println("item :" +quantityList.get(i).getItem()+" : "+ itemPrice);

					}else if(quantityList.get(i).getItem().equalsIgnoreCase("B") && quantityList.get(i).getQuantity()>0){
						itemPrice = 0;
						if(quantityList.get(i).getQuantity()>= 2){
							if(quantityList.get(i).getQuantity()%2 == 0){
								itemPrice = (quantityList.get(i).getQuantity()/2)* 45;
							}else{
								int quotient = quantityList.get(i).getQuantity()/2;
								int remainder = quantityList.get(i).getQuantity()%2;
								itemPrice = remainder * Double.parseDouble(itemBPrice);
								itemPrice += quotient * 45;
							}
						}else{
							itemPrice = quantityList.get(i).getQuantity() * Double.parseDouble(itemBPrice);
						}
						items.setItem(quantityList.get(i).getItem());
						items.setPrice(itemPrice);
						itemsList.add(items);
					}else if(quantityList.get(i).getItem().equalsIgnoreCase("C") && quantityList.get(i).getQuantity()>0){
						itemPrice = 0;
						if(quantityList.get(i).getQuantity()>= 3){
							int quotient = quantityList.get(i).getQuantity()/3;
							itemPrice = quotient * 50;

							int remainder = quantityList.get(i).getQuantity()%3;
							if(remainder%2 == 0){
								itemPrice += (remainder/2) * 38;
							}else{
								itemPrice += remainder * Double.parseDouble(itemCPrice);
							}

						}else if(quantityList.get(i).getQuantity()== 2){
							itemPrice = (quantityList.get(i).getQuantity()/2)* 38;
						}else{
							itemPrice = quantityList.get(i).getQuantity() * Double.parseDouble(itemCPrice);	
						}
						items.setItem(quantityList.get(i).getItem());
						items.setPrice(itemPrice);
						itemsList.add(items);
					}else if(quantityList.get(i).getItem().equalsIgnoreCase("D") && quantityList.get(i).getQuantity()>0){
						itemPrice = 0;


						itemPrice = quantityList.get(i).getQuantity() * Double.parseDouble(itemDPrice);

						items.setItem(quantityList.get(i).getItem());
						items.setPrice(itemPrice);
						itemsList.add(items);

					}else if(quantityList.get(i).getItem().equalsIgnoreCase("E") && quantityList.get(i).getQuantity()>0){
						itemPrice = 0;

						itemPrice = quantityList.get(i).getQuantity() * Double.parseDouble(itemEPrice);

						items.setItem(quantityList.get(i).getItem());
						items.setPrice(itemPrice);
						itemsList.add(items);

					}
				}
			}


		} catch (Exception e) {
			// TODO: handle exception
		}
		return itemsList;

	}
}
